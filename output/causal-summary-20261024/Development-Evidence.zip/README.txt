Saved-output verification (standard library only):
python3 scripts/verify_causal_summary_saved.py causal-summary-dev-20261024
No API access or new inference. Use the main Phase1-Evidence package for full source/dependencies. This companion contains development only, not held-out scores.
