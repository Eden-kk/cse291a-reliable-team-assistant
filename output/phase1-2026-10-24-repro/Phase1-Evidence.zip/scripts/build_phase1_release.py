"""Build a dated Phase 1 report and evidence release without replacing the Oct 8 archive."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, PageBreak, Spacer
from reportlab.lib.pagesizes import letter

ROOT = Path(__file__).resolve().parents[1]
DATE = '2026-10-22'
OUT = ROOT / 'output' / ('phase1-' + DATE)
STAGE = OUT / 'team-assistant-phase1'
PDF = OUT / 'phase1-report.pdf'
if OUT.exists():
    raise ValueError('Release already exists; preserve the reviewed release')
OUT.mkdir(parents=True)
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='Report', fontName='Helvetica', fontSize=10, leading=13, spaceAfter=7))
styles.add(ParagraphStyle(name='Small', fontName='Helvetica', fontSize=8.5, leading=11, spaceAfter=5))
flow = []
text_sections = []
def p(text, style='Report'):
    flow.append(Paragraph(text, styles[style]))
    text_sections.append(text)
def heading(text):
    p(text, 'Heading2')
def table(rows, widths):
    t = Table([[Paragraph(str(x), styles['Small']) for x in row] for row in rows], colWidths=widths)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#EAF0F5')),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.3,colors.HexColor('#CED6DE'))]))
    flow.append(t)
    text_sections.extend(' | '.join(map(str,row)) for row in rows)
p('Reliable Team Assistant', 'Title')
p('Phase 1: Safe Recovery after Shared-State Invalidation<br/>Yiting Dai | Solo | CSE291A Option 5 | October 22, 2026', 'Small')
heading('1. Question, scope and implementation')
p('When an oncall assistant has consumed evidence that later becomes invalid, can dependency-aware recovery preserve answer quality with less recomputation than a full restart? Configuration and telemetry specialists collect read-only Cloud-OpsBench observations; a coordinator diagnoses an incident. A trusted event identifies an invalid source/version or artifact, not the correct diagnosis. Automatic discovery of arbitrary errors is outside scope.')
p('The implementation records consumed inputs and versions, invalidates their dependent closure, retains independent work, rejects obsolete in-flight writes, and links a local correction to the prior publication. Observable missing provenance triggers conservative restart while preserving cumulative token/tool allowances and the historical ledger. Unrecorded implicit dependencies cannot be automatically detected. Shared procedural rules are versioned inputs; learning them and scheduling multiple groups are extensions, not prerequisites for the core claim.')
heading('2. Workload and evaluation protocol')
p('Experiments use existing Online Boutique snapshots from Cloud-OpsBench [1], pinned to ea05dafbc87b5985df8721622d63d4229c2b4224. Model inference sees questions, tool contracts and observations; labels are accessed only for post-inference scoring. Real model calls use a tool-disabled Codex CLI and existing subscription. Constructed transitions/faults are not production incident histories. The eight held-out final cases remain unopened.')
p('The October 21 pilot freezes one already-seen runtime incident, an empty memory policy, one diagnosis round and a fixed method order. No-recovery, restart, selective and incomplete-provenance fallback fork the same consumed prefix with matched cumulative ceilings. Independent consumption-time source verification starts from scratch, since it may prevent the prefix. It checks accessible source identity/content/version, not arbitrary semantic truth.')
p('Quality is reported before savings: native joint target/root accuracy (JRA), native evidence closure (ECR), output contract, and current authentic evidence. A correct root with stale supporting facts fails the declared current-evidence criterion. Physical shared-prefix cost is counted once; logical end-to-end cost includes it for each recovery policy. Uncertain results, provider failures and unknown usage remain visible.')
heading('3. Same-prefix development results')
table([['Policy','Increment tokens','Logical total','Current-evidence outcome'],['No recovery','0','51,755','Fails: stale fact'],['Full restart','51,429','103,184','Pass'],['Selective','19,791','71,546','Pass'],['Provenance fallback','51,753','103,508','Pass']],[115,95,95,199])
p('Shared prefix: 3 calls, 51,755 tokens, 7 tools. Restart/selective/fallback each attain JRA=ECR=1 and 7/7 authentic, current consumed observations. No-recovery also scores JRA=ECR=1, yet retains the old port 9556 after the constructed source changes to 9555. This is factual-detail refresh with an unchanged correct root category, not recovery from a wrong root diagnosis.', 'Small')
flow.append(PageBreak())
p('Results, boundaries and next steps', 'Title')
heading('4. Costs and failed conditions')
p('Selective recovery uses one new model call versus three for restart: 61.52% fewer incremental tokens, or 30.66% fewer logical tokens including the common prefix. Recovery wall times are 11.61s versus 17.82s (fallback 24.92s). One seen incident and fixed order support feasibility, not general or statistically significant speedups. Fallback costs approximately a restart, as expected when safe reuse is unavailable.')
p('Independent verification times out on its final call after 180s and has no final answer in the original batch. The batch has 13 physical calls, 206,619 known tokens plus a 60,000-token unknown-usage reservation. A separately authorized replay of only that failed request succeeds with 19,754 tokens and JRA=ECR=1. It is not a complete end-to-end verification rerun or a successful original condition. Combined accounting is 14 calls, 226,373 known tokens plus the unchanged 60,000 unknown reservation.')
p('The earlier October 8 matrix is retained separately: four predeclared conditions across three seen incidents. Runtime port corruption propagates a false fact; CPU-limit corruption yields uncertainty; service-address mutation fails to match; an adversarial instruction is consumed but does not trigger the forbidden request, and recovery encounters a provider error. Non-propagating and failed conditions remain in the record. Static source checking can be cheap and prevent corruption, so selective recovery is not assumed universally superior.')
heading('5. Provenance controls and overhead')
p('Controlled tests cover explicit incomplete capture/missing parents, cumulative budgets, rejected obsolete commits and linked corrections. Placeholder outputs verify state invariants, not semantic diagnosis. The latest development suite records 174 passing tests; the release records its own extracted-package checks and explicitly reports any snapshot-dependent skips.')
p('A pre-fallback microbenchmark uses synthetic sparse/dense graphs and seven measured repeats after warmup. At 48 nodes, median tracked-commit CPU is 1.378ms sparse and 117.863ms dense, versus approximately 0.164ms for payload-only commit. Source checks cost 0.766/1.028ms. Serialized tracking state is 25,412/33,801 bytes versus 16,109 baseline bytes; these are not RAM measurements. This excludes setup, network and tool recollection, and is not integrated production overhead. Dense dependency tracking is an explicit optimization target.')
heading('6. What Phase 1 establishes')
p('The artifact contains executable recovery mechanisms, frozen development protocols, raw model inputs/outputs, source audits, ledgers, failures and quantitative controls. Feasibility is supported by actual factual refresh and conservative fallback, not just rejection. Small reused development cases, mutable model aliases and constructed faults limit generalization. Local append-only publication is a simulation; no operational writes or crash durability are claimed. CLI tokens include wrapper context and are not API-dollar costs.')
p('The minimum next study completes development controls, freezes affordable held-out cases/fault eligibility and semantic/native metrics, then evaluates recovery quality and costs including failures. Multi-group scheduling is the first extension, independently gated procedural learning the second; neither blocks the core deliverable. Existing learning candidates remain inactive. A negative or boundary result remains valid if measured reproducibly.')
p('AI use: Codex assisted implementation, experiment tooling, analysis and report drafting. Outputs and limitations are recorded for student review. [1] github.com/LLM4Ops/Cloud-OpsBench (MIT). [2] cseweb.ucsd.edu/~yiying/cse291a-fall26/project/ and Option 5 specification.', 'Small')
flow.append(PageBreak())
p('Appendix: timeline and artifact map', 'Title')
p('Timeline appendix, separate from the two-page Phase 1 report.', 'Small')
table([['Target','Milestone','Evidence / exit criterion'],['Completed','Phase 1 prototype and development evidence','Pinned workload, consumed dependencies, recovery/fallback, raw trajectories, source audits and overhead samples'],['Oct 22-27','Reconcile and verify release','Report/README/code/evidence match; clean extraction checks and hashes; student review'],['Oct 28','Phase 1 submission','Course states Oct 28; exact time/upload slots require confirmation; preserve receipt'],['Oct 29-Nov 12','Core development boundary study','Dense/shared invalidation, provenance gaps, complete tracking/verification accounting; topology fixed'],['Nov 13-23','Freeze and execute held-out protocol','Whole-batch budget preflight, eligibility fixed before outcomes, failures retained; no final-set adaptation'],['Nov 24-30','Analyze and optional scheduling','Quality-first paired costs; response/recovery wait and rejection tradeoffs; learning only if time remains'],['Dec 1-10','Final artifact and report','Reproduce tables, document limitations; verify course final requirements']],[82,146,276])
heading('Reproduction and evidence')
p('RELEASE_README.txt provides offline verification commands. MANIFEST.sha256.json indexes included bytes. docs/phase1-matrix-results.json and runs/phase1-matrix preserve the earlier matrix; docs/semantic-recovery-20261021-results.json and matching runs preserve the new same-prefix pilot, source revisions and failure ledger. The separate verification-retry directory retains the failed-request replay. Overhead and fallback artifacts are included without pooling them into semantic results.')
p('Source/tests/configuration and pinned environment are bundled. The offline Cloud-OpsBench evaluator/label subset supports saved-output scoring; full benchmark snapshots require a separately pinned checkout. Package verification never invokes the model provider, creates AWS resources or opens final benchmark cases. A newly generated live replay requires separate user authentication and consumes quota; it is not part of release verification.')
p('The original October 8 report/archive are preserved. This dated release supersedes them for review but is not a Canvas submission receipt. Historical source manifests name the commits used for those experiments; the release manifest separately records the current source commit. Later source changes do not retroactively change the original experimental protocol.')
def footer(canvas, doc):
    canvas.setFont('Helvetica',8)
    canvas.drawString(54,28,'Reliable Team Assistant | Phase 1 | October 22, 2026')
    canvas.drawRightString(558,28,str(doc.page))
SimpleDocTemplate(str(PDF),pagesize=letter,leftMargin=54,rightMargin=54,topMargin=40,bottomMargin=44).build(flow,onFirstPage=footer,onLaterPages=footer)
(OUT/'phase1-report.txt').write_text('\n\n'.join(text_sections)+'\n')
STAGE.mkdir()
def copy(path, relative):
    target = STAGE / relative
    target.parent.mkdir(parents=True,exist_ok=True)
    if path.is_dir():
        shutil.copytree(path,target,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.DS_Store'))
    else:
        shutil.copy2(path,target)
for name in ('src','scripts','tests','configs','pyproject.toml','requirements.lock','requirements-report.txt'):
    copy(ROOT/name,name)
for name in ('phase1-matrix-results.json','phase1-controls.json','current-proposal.txt','experiment-plan.txt','semantic-recovery-pilot-rubric.txt','semantic-recovery-20261021.txt','semantic-recovery-20261021-results.json','semantic-verification-retry-20261021.json','recovery-completion-20261021.txt','recovery-overhead-results.json','provenance-fallback-results.json'):
    copy(ROOT/'docs'/name,Path('docs')/name)
for name in ('phase1-matrix','phase1-port-corruption-v1','phase1-integrity-v2','phase1-controls.json','semantic-recovery-20261021','semantic-verification-retry-20261021','fallback-20261021','overhead-20261021'):
    copy(ROOT/'runs'/name,Path('runs')/name)
copy(PDF,'phase1-report.pdf')
copy(OUT/'phase1-report.txt','phase1-report.txt')
copy(ROOT/'docs/phase1-release-readme.txt','RELEASE_README.txt')
vendor = ROOT.parent/'preparation/291a-team-agent/vendor/Cloud-OpsBench'
for rel in ('agents/cloudops_agent','LICENSE','process-label/boutique/runtime/1','process-label/boutique/service/1','process-label/boutique/performance/1'):
    copy(vendor/rel,Path('vendor_offline/Cloud-OpsBench')/rel)
files={str(p.relative_to(STAGE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(STAGE.rglob('*')) if p.is_file()}
for name in files:
    if Path(name).suffix in ('.pem','.key') or Path(name).name in ('auth.json','.env'):
        raise ValueError('Credential-like file: '+name)
manifest={'source_commit':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),'dataset_commit':'ea05dafbc87b5985df8721622d63d4229c2b4224','files':files}
(STAGE/'MANIFEST.sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=OUT/'phase1-submission.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for path in sorted(STAGE.rglob('*')):
        if path.is_file(): z.write(path,str(path.relative_to(STAGE.parent)))
print(archive)
