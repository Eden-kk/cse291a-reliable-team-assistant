"""Reconcile dated Phase 1 saved evidence without invoking a model provider."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parents[1]
def read(p): return json.loads(p.read_text())
def main():
    compact=read(ROOT/'docs/semantic-recovery-20261021-results.json')
    raw=read(ROOT/'runs/semantic-recovery-20261021/live/summary.json')
    for arm, result in compact['arms'].items():
        for key, value in raw['arms'][arm].items():
            assert result[key] == value, (arm, key)
    ledger=compact['physical_settlements'] if 'physical_settlements' in compact else compact['settlements']
    assert sum(x['actual'] or 0 for x in ledger)==compact['known_recorded_tokens']==206619
    assert sum(x['actual'] is None for x in ledger)==compact['unknown_usage_calls']==1
    assert sum(x['charged'] for x in ledger)==266619
    checked=[]
    with tempfile.TemporaryDirectory() as tmp:
        for arm in ('no-recovery','restart','selective','fallback'):
            path=ROOT/'runs/semantic-recovery-20261021/live'/arm
            if not (path/'scores.json').exists():
                continue
            output=Path(tmp)/(arm+'.json')
            subprocess.run([sys.executable,str(ROOT/'scripts/score_run.py'),str(path),'--vendor',str(ROOT/'vendor_offline/Cloud-OpsBench'),'--output',str(output)],check=True,stdout=subprocess.DEVNULL)
            assert read(output)['scores']==read(path/'scores.json')['scores'], arm
            checked.append(arm)
    assert set(checked)=={'no-recovery','restart','selective','fallback'}, checked
    for arm in ('restart','selective','fallback'):
        assert compact['arms'][arm]['logical_total_tokens']>=51755
    assert (ROOT/'runs/semantic-recovery-20261021/live/source-consistency-from-start/failure.json').is_file()
    retry=read(ROOT/'docs/semantic-verification-retry-20261021.json')
    assert retry['known_tokens']==19754
    assert all(x['authentic'] and x['fresh'] for x in retry['source_audit'])
    print(json.dumps({'semantic_scores_reproduced':checked,'known_tokens':206619,'unknown_reserved_tokens':60000,'retry_known_tokens':19754,'live_model_calls':0}))
if __name__=='__main__': main()
