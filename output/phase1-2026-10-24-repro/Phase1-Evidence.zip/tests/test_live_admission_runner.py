"""Exercise real admission/dispatch orchestration with a fake inference provider."""
import asyncio
import importlib.util
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from team_assistant.dispatch import Budget, Dispatcher, Outcome
SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0,str(SCRIPTS))
SPEC = importlib.util.spec_from_file_location('admission_live',SCRIPTS/'run_admission_live.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class FakeInvestigation:
    def __init__(self, runtime, physical, identifier, fail=False):
        self.runtime, self.physical, self.identifier = runtime,physical,identifier
        self.provider = SimpleNamespace(records=[])
        self.snapshot = SimpleNamespace(observations=[])
        self.tool_errors, self.tool_budget_start = [],0
        self.incident = SimpleNamespace(store=SimpleNamespace(results={}))
        self.deadline, self.fail = None,fail

    async def run(self,reuse=False):
        kind='recovery' if reuse else 'response'
        async def call():
            async def backend():
                self.physical.reserve(60000)
                await asyncio.sleep(0)
                self.physical.settle(60000,10)
                self.provider.records.append({'tokens':10})
                return Outcome({},10,'controlled failure' if self.fail else None)
            return await self.runtime.dispatcher.call(self.identifier,kind,60000,backend,self.deadline)
        if reuse:
            await call()
        else:
            outcomes=await asyncio.gather(call(),call(),return_exceptions=True)
            for result in outcomes:
                if isinstance(result,Exception):raise result
            await call()
        return {'contract_errors':[],'answer':{'status':'uncertain'}}


class LiveAdmissionRunnerTests(unittest.IsolatedAsyncioTestCase):
    async def run_window(self, policy, fail=False, cap=360000):
        physical=Budget(600000)
        physical.spent=30
        base=SimpleNamespace(runtime=SimpleNamespace(dispatcher=Dispatcher(Budget(360000))))
        base.runtime.dispatcher.budget.spent=30
        def branch(*args):
            runtime=SimpleNamespace(dispatcher=Dispatcher(Budget(cap)),events=[])
            runtime.dispatcher.budget.spent=30
            return FakeInvestigation(runtime,physical,'recovery')
        def fresh(path,runtime,spec):
            return FakeInvestigation(runtime,physical,spec['group'], fail and spec['group']=='service')
        manifest={'logical_token_cap':cap,'recovery_case':'boutique/performance/1',
                  'foregrounds':[{'group':'service','case':'boutique/service/1','arrival_seconds':0},
                                 {'group':'runtime','case':'boutique/runtime/1','arrival_seconds':0}]}
        with tempfile.TemporaryDirectory() as directory, patch.object(MODULE,'provider',return_value=None), patch.object(MODULE,'recovery_branch',side_effect=branch):
            result=await MODULE.window(Path(directory),base,physical,policy,manifest,fresh)
        self.assertTrue(result['lifecycle_drained'])
        self.assertEqual(result['logical_total_tokens'], physical.spent)
        self.assertEqual(result['incremental_physical_tokens'], sum(s['charged'] for s in result['settlements']))
        return result

    async def test_successful_three_group_lifecycle(self):
        result=await self.run_window('fair-admit-one')
        events=result['admission_events']
        self.assertEqual([e['group'] for e in events if e['event']=='admitted'],['service','runtime'])
        release=next(e['time'] for e in events if e['event']=='released' and e['group']=='service')
        start=next(e['time'] for e in result['dispatch_events'] if e['event']=='start' and e['group']=='runtime')
        self.assertGreaterEqual(start,release)
        self.assertEqual(result['incremental_physical_tokens'],70)

    async def test_failed_admitted_workflow_releases_next_group(self):
        result=await self.run_window('fair-admit-one',True)
        self.assertEqual(result['outcomes']['service']['state'],'failed')
        self.assertEqual(result['outcomes']['runtime']['state'],'completed')
        self.assertEqual(result['incremental_physical_tokens'],60)

    async def test_baseline_registers_without_admission(self):
        result=await self.run_window('fair-reserve')
        self.assertEqual(result['admission_events'],[])
        self.assertEqual(result['incremental_physical_tokens'],70)

    async def test_cancelled_window_settles_inflight_provider(self):
        physical=Budget(600000)
        started, release = asyncio.Event(),asyncio.Event()
        shared=SimpleNamespace(dispatcher=Dispatcher(Budget(360000)),events=[])
        base=SimpleNamespace(runtime=SimpleNamespace(dispatcher=Dispatcher(Budget(360000))))
        class SlowInvestigation(FakeInvestigation):
            async def run(self,reuse=False):
                async def backend():
                    physical.reserve(60000)
                    started.set()
                    await release.wait()
                    physical.settle(60000,10)
                    self.provider.records.append({'tokens':10})
                    return Outcome({},10)
                await self.runtime.dispatcher.call(self.identifier,'recovery' if reuse else 'response',60000,backend)
                return {'contract_errors':[]}
        manifest={'logical_token_cap':360000,'recovery_case':'boutique/performance/1','foregrounds':[]}
        with tempfile.TemporaryDirectory() as directory, patch.object(MODULE,'provider',return_value=None), patch.object(MODULE,'recovery_branch',return_value=SlowInvestigation(shared,physical,'recovery')):
            task=asyncio.create_task(MODULE.window(Path(directory),base,physical,'fair-admit-one',manifest,None))
            await asyncio.wait_for(started.wait(), 1)
            task.cancel()
            await asyncio.sleep(0)
            release.set()
            with self.assertRaises(asyncio.CancelledError):
                await task
        self.assertEqual(physical.spent,10)
        self.assertEqual(physical.reserved,0)
        self.assertEqual(shared.dispatcher.budget.reserved,0)
        self.assertFalse(shared.dispatcher.pending or shared.dispatcher.running)

    async def test_low_budget_keeps_failed_groups_and_settles(self):
        for policy in ('fair-reserve','fair-admit-one'):
            result=await self.run_window(policy,cap=60030)
            self.assertEqual(set(result['outcomes']),{'recovery','service','runtime'})
            self.assertTrue(any(o['state']=='failed' for o in result['outcomes'].values()))
            self.assertLessEqual(result['logical_total_tokens'],60030)

    async def test_protocol_only_accepts_fixed_caps_and_policy_permutations(self):
        import json
        protocol=json.loads(MODULE.PROTOCOL.read_text())
        for cap in (200000,360000):
            protocol['logical_token_cap']=cap
            protocol['policies'].reverse()
            MODULE.validate_protocol(protocol)
        protocol['policies']=['fair-reserve','fair-reserve']
        with self.assertRaises(ValueError):MODULE.validate_protocol(protocol)
