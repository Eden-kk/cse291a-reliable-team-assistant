Reliable Team Assistant - Phase 1 release 2026-10-22
Author: Yiting Dai, solo, CSE291A Option 5

The report has two body pages plus one timeline appendix. Official Phase 1 date is Oct 28; exact time and upload slots still require live confirmation. This archive is prepared locally, not submitted.

OFFLINE CHECKS (no model calls, no final-case data)
Python >=3.11:
  python3 -m venv .venv
  .venv/bin/python -m pip install -r requirements.lock
  PYTHONPATH=src .venv/bin/python scripts/verify_phase1_package.py
  PYTHONPATH=src .venv/bin/python scripts/verify_phase1_release.py
The first command verifies byte hashes, reconstructs the Oct 8 matrix and native scores, executes controls and current tests. Snapshot-dependent tests may skip without the separate full benchmark checkout. The second reconciles the new saved semantic summaries, cost ledger and native scores against included raw outputs. It verifies stored evidence, not a new inference result. Original scripts can create live model calls; do not run experiment runners for offline verification.

EVIDENCE
Report table: docs/semantic-recovery-20261021-results.json; raw under runs/semantic-recovery-20261021/live. The original verification arm failed. The separate runs/semantic-verification-retry-20261021/attempt-1 is one diagnostic request replay, not successful end-to-end verification. Both failures and unknown-usage reservation remain recorded.
Old matrix: docs/phase1-matrix-results.json and runs/phase1-matrix. This separate development matrix is not pooled with October 21 into independent samples.
Fallback: docs/provenance-fallback-results.json and runs/fallback-20261021.
Overhead: docs/recovery-overhead-results.json and runs/overhead-20261021/report.json; pre-fallback microbenchmark, not integrated production timing.

PROVENANCE AND LIMITS
Cloud-OpsBench https://github.com/LLM4Ops/Cloud-OpsBench commit ea05dafbc87b5985df8721622d63d4229c2b4224. MIT license and offline native evaluator/three required label directories are included under vendor_offline/Cloud-OpsBench. No final benchmark content or credentials is bundled. Full benchmark snapshots are not included; replayed observations needed for auditing are included in raw traces.
Model gpt-6-astra through Codex CLI subscription. Model alias availability and results are not guaranteed immutable. Tokens include CLI wrappers and are not API-dollar charges. Constructed snapshot changes and local publication ledgers are not real incident histories or operational actions. Trusted invalidation is assumed. Unrecorded implicit dependencies, production permissions, crash durability, statistical generalization and broad learned-memory benefits remain outside claims. AI assistance is disclosed in the report.

RELEASE
MANIFEST.sha256.json records current source commit and checksums; original run manifests retain their own historical source commits. Current uncommitted release tooling is included and individually hashed. This is integrity verification, not a signature. The older October 8 archive/report remain untouched. Rendered PDF text is also provided for editing; generation code is scripts/build_phase1_release.py and deliberately refuses to overwrite an existing dated release.

Historical manifests and logs preserve local filesystem paths (including the author home directory) for provenance. These are not credentials. No auth material, API tokens or private keys is intentionally included.
